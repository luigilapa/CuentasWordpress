<?php

namespace CuentasFacturas\Events;

abstract class Event
{
    //
}
