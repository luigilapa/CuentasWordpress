@extends('layout/master')
<?php $title='' ?>
@section('content')
    <div class="row" style="text-align: center;">
        <div class="col-lg-12">
            <span class="glyphicon glyphicon-ban-circle text-danger"><h2>Error 401</h2></span>
            <h3>No se encuentra autorizado para ver el contenido de esta p&#225;gina.</h3>
        </div>
    </div>
@endsection